import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import org.json.JSONObject;

public class CurrencyConverter {

    // Method to fetch exchange rate from API
    public static double getExchangeRate(String baseCurrency, String targetCurrency) throws Exception {
        String apiKey = "your_api_key"; // Replace with your API key
        String urlStr = String.format("https://v6.exchangerate-api.com/v6/%s/latest/%s", apiKey, baseCurrency);

        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String inputLine;
        StringBuilder content = new StringBuilder();
        while ((inputLine = in.readLine()) != null) {
            content.append(inputLine);
        }

        in.close();
        conn.disconnect();

        JSONObject jsonObject = new JSONObject(content.toString());
        return jsonObject.getJSONObject("conversion_rates").getDouble(targetCurrency);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Input base currency and target currency
            System.out.print("Enter the base currency (e.g., USD, EUR, INR): ");
            String baseCurrency = scanner.next().toUpperCase();

            System.out.print("Enter the target currency (e.g., USD, EUR, INR): ");
            String targetCurrency = scanner.next().toUpperCase();

            // Input amount to convert
            System.out.print("Enter the amount to convert: ");
            double amount = scanner.nextDouble();

            // Fetch exchange rate
            double exchangeRate = getExchangeRate(baseCurrency, targetCurrency);

            // Perform conversion
            double convertedAmount = amount * exchangeRate;

            // Display result
            System.out.printf("Converted Amount: %.2f %s%n", convertedAmount, targetCurrency);

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}
